# R05–R06 合同迁移审阅稿

补丁的唯一目标文件是 `ContinuousFlexibility/Statements/Radial.lean`。
基线 SHA256 为 `65f720ce26a72378f8e4857566653807b5cf3f11350dd96d7bcf0ec8a52e403c`。
试应用后的预期 SHA256 为 `c7ce42f6da17b0f68863a55865380e25b34f61b10c58720f599a33beef257bcd`。
补丁保留基线源码的 CRLF 行尾，供总控审核、应用和编译。

## R05 的积分区间

手稿使用 $X_c=-\log(3/2)$ 和右转点
$X_R=-\log((1-\sqrt{1-4B/A})/2)$。补丁在同一个 `T.radius` 上固定这些位置，
要求 $0<B$ 和 $4B<A$，并沿用现有保留单元构造的 $\delta=c_R=1/100$。
半径缩放后的初速为 $r_X(X_R)=\delta A^5 r(X_R)$，保留右端为 $X_R+c_R/A^4$。
这两个常数对所有侧别、编号和高度选择相同。
[手稿 §5](../paper/flexible-surface-rewrite/05-flat-end-chain.tex#L71) ·
[帽长和初速的构造](../ContinuousFlexibility/Radial/MorseRightCapBounds.lean#L344) ·
[保留单元](../ContinuousFlexibility/Radial/MorseCellLiouville.lean#L134)

令 $L_k,C_k,U_k$ 分别为保留左端、右转点和长帽右端的物理半径。
`morseCellMass` 与 `morseCellResistance` 在 $[L_k,C_k]$ 积分。
`morseJoinMass` 与 `morseJoinResistance` 保留调用名，积分范围改为从 $C_k$
到长帽后沿半径递增方向的实际胶段终点。

| 侧别和编号 | 阻力段 | Lean 的右端 |
| --- | --- | --- |
| 右侧 | $[C_k,L_{k+1}]$ | `joinRight true k` |
| 左侧且 `T.index < k` | $[C_k,L_{k-1}]$ | `joinRight false (k - 1)` |
| 左侧且 `k = T.index` | $[C_k,U_k]$ | 保留单元右端 |

四个积分使用 $wr^6\,dr$ 和 $dr/(wr^8)$ 两种密度。
`MorseMassResistanceBounds` 的量级和量词保留。
首格长帽自身具有 $\nu\lesssim\lambda A^6$ 和 $R\asymp\lambda^{-1}A^{-4}$，
足以给截断边同样的界。 [手稿质量、阻力和胶段误差](../paper/flexible-surface-rewrite/05-flat-end-chain.tex#L184)

`morseChainRightTurn` 的公式与现有 `Radial.morseRightTurn` 定义相同。
后者所在模块经过 `MorseChainScales` 导入本陈述模块。局部定义公式避免循环导入。

## R05 的相邻块重叠

右侧 $s_k=L_k$，左侧 $s_k=U_k$。原块 $B_k$ 是 $s_k,s_{k+1}$ 之间的闭区间。
当前支撑合同把高编号局部化限制在这些闭块内。足够深的接缝只能被相邻高编号覆盖，
而局部化函数若在接缝处非零，其非零邻域就会跨缝，导致单位分解无法成立。

令 $h_k=|s_{k+1}-s_k|$，$d_k=\min(s_k-a,b-s_k)$，用
$\epsilon_k=\min(d_k,h_{k-1},h_k)/16$ 扩张接缝两侧。
首格用两侧入口之间的中段长度代替 $h_{k-1}$。
各块只跨相邻块的一小段。两端各扩张至多 $h_k/16$，所以扩张块长度至多 $9h_k/8$。
接缝处的扩张也至多其端距的 $1/16$，因此保留原端距界的量级。

每个高编号 `D.cells m` 落在对应侧和编号的扩张块内。
另要求原块的每一点都有同编号的 `D.cells` 覆盖，接缝允许两个相邻编号均有覆盖。
`AccumulatingProfileBounds` 继续要求长度、端距、轮廓及逆轮廓 jet、光滑单位分解
和 `RadialTraceScaffold`。这些条件须在构造中证明。

可在每个接缝的 $\epsilon_k$ 邻域取一个向外递增的光滑阶跃，
相邻阶跃之差给尾部 localizer，两侧首阶跃的余量给中段 localizer。
原块内部可选中点和半宽 $h_k/8$ 作 trace collar。
若用一个有限中段 localizer，可取 `T.index ≥ 1` 并选正编号且不超过 `T.index`。
原合同在编号零处的轮廓下界为 $w\ge1$，正编号让有限中段的常数可以适应实际轮廓。
[手稿的光滑单位分解](../paper/flexible-surface-rewrite/04-designing-the-profile.tex#L59) ·
[端距和轮廓 jet 界](../paper/flexible-surface-rewrite/05-flat-end-chain.tex#L158)

## R06 的外向标号与初边

令 $k=\texttt{start}+n$。右侧 $x=\log r$，节点和质量段末端分别为
$\log L_k,\log C_k$，入口是首节点，整条普通边用 $k$。
左侧 $x=-\log r$，两者分别为 $-\log C_k,-\log L_k$。
在 $-\log U_{k+1}$ 切分，质量段与胶段用 $k$，下一长帽用 $k+1$。
在分界点取 $k+1$ 的覆盖。左侧普通边的阻力来自原始 $J_{k+1}$，
故递推分母是 $\Lambda\mu_{k+1}R_{k+1}$。

实际 Morse 链提供 `TailPhysicalLocalization` 左侧入口的两种实例。

- 长帽初边从 $-\log U_{\texttt{start}}$ 到首节点，整段用 `start`。
- 完整初边从 $-\log L_{\texttt{start}-1}$ 到首节点，在
  $-\log U_{\texttt{start}}$ 分段。胶段用 `start - 1`，长帽用 `start`。
  该实例须有 `T.index < start`，这里 `T.index` 是 Morse 链的起始编号。
  抽象 `TailPhysicalLocalization` 的前提只有 `ReferenceData` 与 `DeepTailData`，
  完整分支用 `0 < start` 保护自然数前驱，并要求实际前一编号覆盖非空胶段。
  从 R05 实例化 R06 时，须用同一条实现链证明上述切点等式。

手稿区分 R07 的过渡单元 $n$ 与 R06 的深尾首格 $n+1$。
左侧深尾在第 6 节的分解下从完整初边的入口开始。若实现选择长帽入口，可把前一胶段
计入过渡区并验证其传输界。构造首格的左尾可从实际 $U_k$ 直接开始。
[手稿 §5](../paper/flexible-surface-rewrite/05-flat-end-chain.tex#L273) ·
[手稿 §6](../paper/flexible-surface-rewrite/06-global-reference-inverse.tex#L356)

`DeepTailHypotheses` 已有初边的三个预算
$\Lambda\nu_{\rm init}R_{\rm init}\le\eta$、
$\nu_{\rm init}\le\eta\mu_0$、
$\Lambda\mu_0R_{\rm init}\ge K$。
入口归一化、首节点衰减、阻抗和初边 Green/Poisson 估计仍是证明输出。
现有 `TailGreenKernel` 的局部点态界覆盖普通节点边。§6 若在初边使用该界，
须从初边的 Dirichlet 核与插值公式另证对应块。

`TailPhysicalRelation` 保留密度公式、增长下界和调用类型。
物理密度与模式二比较密度之比为 $r_\partial^{-8}(r/r_\partial)^{2(j^2-4)}$。
深频率条件使后一因子有一致双向界，常数因子在质量与阻力的乘积中抵消。
左侧用正测度。相邻标号的 $S_{k+1}-S_k=O(k^2)$ 和
$q_{k+1}-q_k=O(k^{3/2}\log k)$ 可计入 $\mathcal E_k$ 的固定幂，
`TailPhysicalFlatConclusion` 可沿用当前输出尺度。

## 量词与发布范围

- 补丁保留 `MorseChainData`、`DeepTailData`、`ReferenceData` 的字段和现有声明调用名。
  `R05Statement` 和 `R06Statement` 仍是闭合 `Prop`。
- `R05Statement` 的几何 $T$ 与估计常数先于全体高度选择。
  原合同的跨高度相等条件覆盖 `a`、`b`、`cells`。
  当前验收条件未明确是否还要要求 `cellIndex` 和具体 `localizer` 跨高度相等。
  补丁要求每个高度选择的原块及其编号覆盖都相同。
- `TailPhysicalRelation` 的切点在每条左边分别量化，条件表达实际物理点的覆盖。
  将实现链提升为显式参数可以直接约束切点。本稿保持调用类型，具体实例化用同一条链的切点等式。
- `IsSelectedTail` 直接使用修订后的 R05 谓词，R07 和 R08 因而继承修订。
  R07 的过渡入口是右 $L_n$、左 $U_n$。R09–R12 通过
  `IsAccumulatingProfile`、`RadialReference` 等现有接口消费成果。

## 重编与核验

公共改动点为 `ContinuousFlexibility.Statements.Radial`。
按准备补丁时的源码导入图，当前两个默认入口 `ContinuousFlexibility` 与 `AxiomAudit`
的受影响闭包共有 **49 个模块**，含改动模块及两个入口。

```text
AxiomAudit
ContinuousFlexibility
ContinuousFlexibility.Analysis.AffineMaterialData
ContinuousFlexibility.Analysis.ControlCellEndpointBounds
ContinuousFlexibility.Analysis.CylinderMixedJets
ContinuousFlexibility.Analysis.MaterialCylinderPointwise
ContinuousFlexibility.Analysis.MaterialEndpointDecay
ContinuousFlexibility.Analysis.MaterialHeightExtension
ContinuousFlexibility.Analysis.MaterialHeightRegularity
ContinuousFlexibility.Analysis.MaterialLocalComparison
ContinuousFlexibility.Analysis.MaterialLogJets
ContinuousFlexibility.Analysis.MaterialOrdinaryJets
ContinuousFlexibility.Analysis.ProjectiveNewtonCorrectionBounds
ContinuousFlexibility.Analysis.ProjectiveNewtonRecurrence
ContinuousFlexibility.Analysis.ProjectiveNewtonSmoothing
ContinuousFlexibility.Analysis.ProjectiveNewtonTameBounds
ContinuousFlexibility.Analysis.StateControlDecay
ContinuousFlexibility.Analysis.StateControlEndpointClosure
ContinuousFlexibility.Analysis.StateKappaBounds
ContinuousFlexibility.Analysis.StateProfileRegularity
ContinuousFlexibility.Analysis.WeakBranchCore
ContinuousFlexibility.Radial.CentralFullStatement
ContinuousFlexibility.Radial.CentralStatementBridges
ContinuousFlexibility.Radial.GeneralLiouvilleLocalConjugacy
ContinuousFlexibility.Radial.GeneralLiouvilleTransport
ContinuousFlexibility.Radial.MorseCellJoinCollars
ContinuousFlexibility.Radial.MorseCellLiouville
ContinuousFlexibility.Radial.MorseCellMassTravel
ContinuousFlexibility.Radial.MorseChainParameters
ContinuousFlexibility.Radial.MorseChainRadiusPlacement
ContinuousFlexibility.Radial.MorseChainScales
ContinuousFlexibility.Radial.MorseDarbouxForms
ContinuousFlexibility.Radial.MorseLeftCapBounds
ContinuousFlexibility.Radial.MorseLeftCapIntegrals
ContinuousFlexibility.Radial.MorseMaximalDomain
ContinuousFlexibility.Radial.MorsePartnerWeakGraph
ContinuousFlexibility.Radial.MorsePotentialEnergy
ContinuousFlexibility.Radial.MorseRightCapBounds
ContinuousFlexibility.Radial.MorseWeylExclusion
ContinuousFlexibility.Radial.MorseWeylSequence
ContinuousFlexibility.Radial.TailEdgeEnergy
ContinuousFlexibility.Statements.Analysis
ContinuousFlexibility.Statements.Audit
ContinuousFlexibility.Statements.Milestones
ContinuousFlexibility.Statements.Nonlinear
ContinuousFlexibility.Statements.NonlinearCompletion
ContinuousFlexibility.Statements.Radial
ContinuousFlexibility.Statements.RadialTargets
ContinuousFlexibility.Statements.ScalarWeighted
```

另有 **25 个**依赖模块位于当前默认导入闭包外。
纳入发布时，按相应模块单独构建，或随总控新入口一起构建。

```text
ContinuousFlexibility.Analysis.AffineMaterialSampling
ContinuousFlexibility.Analysis.MaterialRadialExpansion
ContinuousFlexibility.Analysis.NegativeComponentOpticalControl
ContinuousFlexibility.Analysis.OpticalTravelVariation
ContinuousFlexibility.Analysis.ProjectiveNewtonSchedule
ContinuousFlexibility.Analysis.ProjectiveNewtonSeed
ContinuousFlexibility.Analysis.ProjectiveNewtonTameData
ContinuousFlexibility.Radial.MorseAdjacentJoin
ContinuousFlexibility.Radial.MorseArithmeticGap
ContinuousFlexibility.Radial.MorseCellModelJets
ContinuousFlexibility.Radial.MorseCellPhysicalJets
ContinuousFlexibility.Radial.MorseChainEndpointDistances
ContinuousFlexibility.Radial.MorseChainFlatExtension
ContinuousFlexibility.Radial.MorseChainLocalGluing
ContinuousFlexibility.Radial.MorseDarbouxGround
ContinuousFlexibility.Radial.MorseDarbouxIntertwining
ContinuousFlexibility.Radial.MorseDiscreteSpectrum
ContinuousFlexibility.Radial.MorseJoinActualGerms
ContinuousFlexibility.Radial.MorseJoinHeightContrast
ContinuousFlexibility.Radial.MorseTravelIntegral
ContinuousFlexibility.Radial.TailEdgeKernel
ContinuousFlexibility.Radial.TailEdgeMassResistance
ContinuousFlexibility.Radial.TailEdgePerturbedGreen
ContinuousFlexibility.Radial.TailEdgePoissonComparison
ContinuousFlexibility.Radial.TailEdgeZeroGreen
```

应用后由总控用 `LEAN_NUM_THREADS=4` 先核对改动模块，再运行
`lake --wfail build`。使用 `python ContinuousFlexibility/Statements/check_statements.py --build`
重新绑定 58 项陈述登记和公理审计证据，保留历史冻结审计。发布时按当时的根导入重新计算闭包。
本稿的核验范围为补丁文本试应用与源码审阅，Lean 编译结果由总控发布。
